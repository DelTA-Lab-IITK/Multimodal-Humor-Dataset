CUDA_VISIBLE_DEVICES=5 python train.py --cuda --mos|tee log_all.txt

